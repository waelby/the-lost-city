#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "robot.h"

void robot_Init(robot *c){
	c->image = IMG_Load("1.png");
	c->image2 = IMG_Load("2.png");
	c->position.x = 200;
	c->position.y = 350;
	c->vx = 5; 
	c->vy = 0;
	
	for (int i = 0; i < 5; i++ ){
		c->clips[i].x = i*250;
		c->clips[i].y = 0;
		c->clips[i].w = 250;
		c->clips[i].h = 250;
	}
	for (int i = 0; i < 5; i++ ){
		c->clips2[i].x = 1536 -(i + 1) * 250;
		c->clips2[i].y = 0;
		c->clips2[i].w = 250;
		c->clips2[i].h = 250;
	}
	
	c->frame = 0;
}

void robot_Render(robot *c, SDL_Surface **screen){
	if(c->vx >= 0){
		SDL_BlitSurface(c->image,&c->clips[(int) c->frame],*screen,&c->position);
	}else{
		SDL_BlitSurface(c->image2,&c->clips2[(int) c->frame],*screen,&c->position);

	}

	c->frame += 0.15f;
	if(c->frame > 5) {
		 c->frame = 0;
		c->vx *= -1;
	}
	c->position.x += c->vx;
		
}
