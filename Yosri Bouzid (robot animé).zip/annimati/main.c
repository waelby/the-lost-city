#include<SDL/SDL.h>
#include"robot.h"

int main()
{
	SDL_Surface *screen;
	SDL_Event e;

	screen = SDL_SetVideoMode(800,600,32,SDL_HWSURFACE);

	robot c;
	robot_Init(&c);


	int running = 1;

	while(running)
		{
		while(SDL_PollEvent(&e))
			{
			if(e.type == SDL_QUIT || e.key.keysym.sym == SDLK_ESCAPE){
				running = 0;
			}
		}

		SDL_FillRect(screen,NULL,0x000000);

		robot_Render(&c,&screen);

		SDL_Delay(30);
		SDL_Flip(screen);
		}	
	SDL_Quit();
}
