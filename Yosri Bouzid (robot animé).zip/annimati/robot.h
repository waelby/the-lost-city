#pragma once


typedef struct robot{

	int x,y,vx,vy;
	SDL_Surface *image, *image2;
	SDL_Rect position;
	SDL_Rect clips[5];
	SDL_Rect clips2[5];
	float frame;
} robot;

void robot_Init(robot *c);
void robot_Render(robot *c, SDL_Surface **screen);

